#include "RenderingGeometryApp.h"
int main()
{
	Application* app = new RenderingGeometryApp();
	app->run("Rendering Geometry", 720, 800, false);
}